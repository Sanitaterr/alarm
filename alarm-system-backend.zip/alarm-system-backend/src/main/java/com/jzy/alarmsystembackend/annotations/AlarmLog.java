//package com.jzy.alarmsystembackend.annotations;
//
//
//import com.jzy.alarmsystembackend.service.impl.log.AlarmUpdateLogServiceImpl;
//import org.springframework.core.annotation.AliasFor;
//import org.springframework.stereotype.Component;
//
//import java.lang.annotation.*;
//
//
//@Target({ElementType.METHOD, ElementType.ANNOTATION_TYPE})
//@Retention(RetentionPolicy.RUNTIME)
//@AlarmType
//@Loggable(AlarmUpdateLogServiceImpl.class)
//public @interface AlarmLog {
//    @AliasFor(annotation = AlarmType.class)
//    String value();
//}
