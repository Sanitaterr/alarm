//package com.jzy.alarmsystembackend.annotations;
//
//import org.springframework.stereotype.Component;
//
//import java.lang.annotation.*;
//
//@Inherited
//@Target({ElementType.METHOD, ElementType.ANNOTATION_TYPE})
//@Retention(RetentionPolicy.RUNTIME)
//@Component
//public @interface AlarmType {
//    String value() default "";
//}
