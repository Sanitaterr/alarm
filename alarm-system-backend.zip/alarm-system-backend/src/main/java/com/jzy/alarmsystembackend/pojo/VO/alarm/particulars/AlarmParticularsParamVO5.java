package com.jzy.alarmsystembackend.pojo.VO.alarm.particulars;

import lombok.Data;

import java.io.Serializable;

/**
 * type
 */
@Data
public class AlarmParticularsParamVO5 implements Serializable {

    private static final long serialVersionUID = -3241613892971703975L;
    private String type;
}
