package com.jzy.alarmsystembackend.pojo.VO.alarm.particulars;

import lombok.Data;

import java.io.Serializable;

/**
 * id
 */
@Data
public class AlarmParticularsParamVO1 implements Serializable {

    private static final long serialVersionUID = -6905429311495517325L;
    private Integer id;
}
