package com.jzy.alarmsystembackend.pojo.VO.alarm;

import lombok.Data;

import java.io.Serializable;

/**
 * id
 */
@Data
public class AlarmParamVO2 implements Serializable {

    private static final long serialVersionUID = -1606026595792276150L;
    private Integer id;
}
