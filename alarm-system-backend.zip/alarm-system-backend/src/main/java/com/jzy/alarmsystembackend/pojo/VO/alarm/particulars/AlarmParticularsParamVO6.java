package com.jzy.alarmsystembackend.pojo.VO.alarm.particulars;

import lombok.Data;

import java.io.Serializable;

/**
 * time
 */
@Data
public class AlarmParticularsParamVO6 implements Serializable {

    private static final long serialVersionUID = -3370003581152251428L;
    private String time;
}
